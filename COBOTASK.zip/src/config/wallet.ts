import * as CoboWaas2 from '@cobo/cobo-waas2';

export const SUPPORTED_CHAINS = {
  BTC: 'BTC',
  ETH: 'ETH',
  POLYGON: 'POLYGON',
};

export const NETWORK_NAMES = {
  BTC: 'Bitcoin',
  ETH: 'Ethereum',
  POLYGON: 'Polygon',
};

export const DEFAULT_CHAIN = SUPPORTED_CHAINS.ETH;

const environment = import.meta.env.VITE_COBO_ENV || 'dev';

// Debugging: Check if CoboWaas2 is properly imported
console.log(CoboWaas2, "CoboWaas2 Import");

// Ensure ApiClient exists
if (!CoboWaas2 || !CoboWaas2.ApiClient) {
  throw new Error("CoboWaas2.ApiClient is undefined. Check package import.");
}

// Initialize API client
const apiClient = CoboWaas2.ApiClient.instance;
console.log(apiClient, "apiClient");

// Set environment
if (environment === 'dev') {
  if (!CoboWaas2.Env) {
    throw new Error("CoboWaas2.Env is undefined.");
  }
  apiClient.setEnv(CoboWaas2.Env.DEV);
}

// Get private key from environment variables
const privateKey = import.meta.env.VITE_COBO_API_PRIVATE_KEY;
console.log("Private Key:", privateKey);

if (!privateKey) {
  throw new Error('Missing required Cobo API private key');
}

// Try setting the private key
try {
  apiClient.setPrivateKey(privateKey);
} catch (error) {
  console.error('Failed to initialize Cobo WaaS 2.0 SDK:', error);
  throw error;
}

// Ensure WalletsApi is available
if (!CoboWaas2.WalletsApi) {
  throw new Error("CoboWaas2.WalletsApi is undefined. Check package import.");
}

// Initialize wallet API instance correctly
const walletApi = new CoboWaas2.WalletsApi();
console.log(walletApi, "walletApi initialized");

export { apiClient, walletApi };
